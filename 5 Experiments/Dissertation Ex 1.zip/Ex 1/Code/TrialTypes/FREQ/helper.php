<?php
    $outputColumns = array('JOL', 'RT', 'RTfirst', 'RTlast');
