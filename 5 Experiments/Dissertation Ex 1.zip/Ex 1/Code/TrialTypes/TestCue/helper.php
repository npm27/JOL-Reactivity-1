<?php
    $outputColumns = array('RT', 'Response', 'ResponseComplete', 'Accuracy', 'RTfirst', 'RTlast', 'strictAcc', 'lenientAcc');
