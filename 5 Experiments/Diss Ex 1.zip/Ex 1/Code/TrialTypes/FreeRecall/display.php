<div>
    <div class="textarea-label shim"><?php echo $text; ?></div>
    <textarea class="fr-textarea collectorInput" name="Response" wrap="physical" value=""></textarea>
</div>
  
<div class="textright">
    <button class="collectorButton collectorAdvance" id="FormSubmitButton">Submit</button>
</div>