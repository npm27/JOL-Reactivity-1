<?php
    $outputColumns = array('RT', 'Response', 'Accuracy', 'RTfirst', 'RTlast', 'strictAcc', 'lenientAcc', 'strictVal', 'lenientVal', 'possibleVal', 'matchedAns', 'unmatchedAns', 'unmatchedResp', 'Errors', 'Selectivity_Index');
