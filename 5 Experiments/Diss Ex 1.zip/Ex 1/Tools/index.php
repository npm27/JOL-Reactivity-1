<?php

?>

<!DOCTYPE HTML>
<head>
    <link href="../Code/css/global.css"  rel="stylesheet"   type="text/css"/>
    <link href="../Code/javascript/jquery-1.10.2.min.js"       type="text/javascript"/>
</head>
<html>
	<body>
		<p>To use tools your server must be configured to allow the use of <em>.htaccess<em> files.</p>
		<p>If you are seeing this page then your server is not configured to use <em>.htaccess<em> files and you must ask your host to allow this feature.</p>
	</body>
</html>